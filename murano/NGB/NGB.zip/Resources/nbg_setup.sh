#!/bin/bash

# $1 - NAME
# $2 - IP
# $3 - ETCD_INITIAL_CLUSTER

mkdir /tmp/Binary

  cp -f BinariesForTesting.tar /tmp/Binary/

